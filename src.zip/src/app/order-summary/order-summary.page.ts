import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order-summary',
  templateUrl: './order-summary.page.html',
  styleUrls: ['./order-summary.page.scss'],
})
export class OrderSummaryPage implements OnInit {

  constructor(private router: Router) {}

  goBack() {
    this.router.navigate(['/tabs/tab1']);  // Replace with the correct path
  }

  ngOnInit() {
  }

}
